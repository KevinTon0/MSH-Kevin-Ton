/*
	Author: Kevin Ton,
	Project: MSH Piping and Forking
	Filename: forking.h
*/

#ifndef FORKING_H
#define FORKING_H

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

void forkingpid();

#endif
