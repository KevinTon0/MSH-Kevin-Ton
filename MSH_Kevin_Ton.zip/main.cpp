/*
	Author: Kevin Ton,
	Project: MSH Piping and Forking
	Filename: main.cpp
*/

#include "forking.h"
#include "piping.h"

using namespace std;

int main(){
	forkingpid();
	//pipelink(buf);
	return 0;
}
